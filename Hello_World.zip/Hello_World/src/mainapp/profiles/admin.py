from django.contrib import admin

from .models import Profiles

admin.site.register(Profiles)
