from django.db import models

TYPE_CHOICES = (
    ('Mr.','Mr.'),
    ('Mrs.','Mrs.'),
    ('Ms.', 'Ms.'),
    ('Dr.', 'Dr.'),
)
class Profiles(models.Model):
    type = models.CharField(max_length=60, choices=TYPE_CHOICES, default='Mr.')
    first_name = models.CharField(max_length=30, default="", blank=True, null=False)
    last_name = models.CharField(max_length=30, default="", blank=True, null=False)
    email = models.CharField(max_length=60, default="", blank=True, null=False)
    username = models.CharField(max_length=30, default="", blank=True, null=False)

    objects = models.Manager()

    def __str__(self):
        return self.first_name