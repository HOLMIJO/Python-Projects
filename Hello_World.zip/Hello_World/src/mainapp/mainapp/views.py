from django.http import HttpResponse
from django.shortcuts import render

def home(request):
    names = ["Joseph Holmin", "Rebecca Holmin", "Brandon Holmin", "Stephen Patterson", "Bill Hale", "John Underwood"]
    context = {
        'names': names,
    }
    return render(request, "home.html", context)